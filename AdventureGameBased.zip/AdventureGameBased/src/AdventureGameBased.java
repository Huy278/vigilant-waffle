
public class AdventureGameBased {
	public static void main(String[] args) {
		System.out.print("Hello world");
		//code things3
	}
}
